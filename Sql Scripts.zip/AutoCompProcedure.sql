USE [JobsDB]
GO

/****** Object:  StoredProcedure [dbo].[autocomp]    Script Date: 02/12/2019 09:05:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[autocomp]
@word varchar(150)
AS
BEGIN
SELECT JobTitleText FROM [LuJobTitle] WHERE JobTitleText 
     LIKE '%'+ @word + '%' 
UNION
SELECT job_description FROM [Jobs] WHERE job_description 
    LIKE '%'+ @word + '%' 
ORDER BY 1 
END
GO

