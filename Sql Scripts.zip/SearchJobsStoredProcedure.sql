USE [JobsDB]
GO

/****** Object:  StoredProcedure [dbo].[SearchJobs]    Script Date: 28/11/2019 09:08:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SearchJobs]
@word varchar(150)
AS
BEGIN
SELECT Distinct [LuJobTitle].[JobTitleID],[JobId],[JobTitleText],[dbo].[Jobs].[job_description]
FROM [dbo].[LuJobTitle] INNER JOIN [dbo].[Jobs] on [dbo].[LuJobTitle].JobTitleID = [dbo].[Jobs].jobTitleId
WHERE JobTitleText LIKE '%' + @word + '%'or [job_description]  LIKE '%' + @word + '%';
END
GO

